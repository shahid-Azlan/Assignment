#include <iostream>

using namespace std;

// Node structure for a linked list
struct Node {
    int data;
    Node* next;
};

class LinkedList {
private:
    Node* head;  // Points to the head of the linked list

public:
    LinkedList() {
        head = NULL;
    }

    // Function to insert a node at the end of the list
    void insertAtEnd(int value);

    // Function to display the linked list
    void display();
};

void LinkedList::insertAtEnd(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* last = head;
    while (last->next != NULL)
        last = last->next;

    last->next = newNode;
}

void LinkedList::display() {
    cout << "The linked list is:" << endl;
    Node* temp = head;

    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    cout << "****head address:**** " << head << endl;
    cout << "----------------------------------------" << endl;

    temp = head;
    int nodeCount = 1;

    while (temp != NULL) {
        cout << "head content: " << temp << endl;
        cout << "----------------------------------------" << endl;
        cout << "****ptr address:**** " << temp->next << endl;
        cout << "----------------------------------------" << endl;
        cout << "ptr content: " << temp->next << endl;
        cout << "----------------------------------------" << endl;

        cout << "ptr->data : " << temp->data << endl;
        cout << "----------------------------------------" << endl;
        cout << "ptr: " << temp << endl;

        if (temp->next != NULL) {
            cout << "ptr->next :  " << temp->next << endl;
            cout << "ptr->data : " << temp->next->data << endl;
        } else {
            cout << "ptr->next :  NULL" << endl;
            cout << "ptr->data : NULL" << endl;
        }

        cout << "----------------------------------------" << endl;

        temp = temp->next;
        nodeCount++;
    }
}

int main() {
    LinkedList list;

    // Inserting elements into the linked list
    list.insertAtEnd(1);
    list.insertAtEnd(2);
    list.insertAtEnd(20);
    list.insertAtEnd(30);

    // Display the linked list and associated information
    list.display();

    return 0;
}

