#include <iostream>

using namespace std;

// Node structure for a linked list
struct Node {
    int data;
    Node* next;
    Node* prev;  // Used for doubly linked list
};

class LinkedList {
private:
    Node* head;  // Points to the head of the linked list

public:
    LinkedList() {
        head = NULL;
    }

    // Function to insert a node at the beginning of the list
    void insertAtBeginning(int value);

    // Function to insert a node at the end of the list
    void insertAtEnd(int value);

    // Function to insert a node at a specific position in the list
    void insertAtPosition(int value, int position);

    // Function to delete a node with a given value
    void deleteNode(int value);

    // Function to display the linked list
    void display();

    // Function to reverse the linked list
    void reverse();

    // Function to seek a specific data node and print its position
    void seek(int value);
};

void LinkedList::insertAtBeginning(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = head;
    newNode->prev = NULL;

    if (head != NULL)
        head->prev = newNode;

    head = newNode;
}

void LinkedList::insertAtEnd(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        newNode->prev = NULL;
        head = newNode;
        return;
    }

    Node* last = head;
    while (last->next != NULL)
        last = last->next;

    last->next = newNode;
    newNode->prev = last;
}

void LinkedList::insertAtPosition(int value, int position) {
    Node* newNode = new Node();
    newNode->data = value;

    if (position == 1) {
        newNode->next = head;
        newNode->prev = NULL;

        if (head != NULL)
            head->prev = newNode;

        head = newNode;
        return;
    }

    Node* temp = head;
    for (int i = 1; i < position - 1 && temp != NULL; i++)
        temp = temp->next;

    if (temp == NULL) {
        cout << "Invalid position. Insertion failed.\n";
        return;
    }

    newNode->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
    newNode->prev = temp;
}

void LinkedList::deleteNode(int value) {
    Node* temp = head;

    // Find the node to be deleted
    while (temp != NULL && temp->data != value)
        temp = temp->next;

    if (temp == NULL) {
        cout << "Node with the given value not found.\n";
        return;
    }

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    delete temp;
}

void LinkedList::display() {
    Node* temp = head;

    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void LinkedList::reverse() {
    Node* current = head;
    Node* temp = NULL;

    while (current != NULL) {
        temp = current->prev;
        current->prev = current->next;
        current->next = temp;
        current = current->prev;
    }

    if (temp != NULL)
        head = temp->prev;
}

void LinkedList::seek(int value) {
    Node* temp = head;
    int position = 1;

    while (temp != NULL) {
        if (temp->data == value) {
            cout << "Node with value " << value << " found at position " << position << endl;
            return;
        }
        temp = temp->next;
        position++;
    }

    cout << "Node with value " << value << " not found in the linked list.\n";
}

int main() {
    LinkedList sll;  // Singly linked list
    LinkedList dll;  // Doubly linked list
    LinkedList cll;  // Circular linked list

    int listChoice, operationChoice;
    int value, position;

    while (true) {
        cout << "Which linked list you want:\n";
        cout << "1: Single\n2: Double\n3: Circular\n";
        cout << "Enter your choice (1-3): ";
        cin >> listChoice;

        switch (listChoice) {
            case 1:
                cout << "You selected Single linked list.\n";
                break;
            case 2:
                cout << "You selected Double linked list.\n";
                break;
            case 3:
                cout << "You selected Circular linked list.\n";
                break;
            default:
                cout << "Invalid choice. Exiting...\n";
                return 0;
        }

        while (true) {
            cout << "\nWhich operation you want to perform:\n";
            cout << "1: Insertion\n2: Deletion\n3: Display\n4: Reverse\n5: Seek\n6: Exit\n";
            cout << "Enter your choice (1-6): ";
            cin >> operationChoice;

            switch (operationChoice) {
                case 1:
                    cout << "Choose insertion option:\n";
                    cout << "1: Insertion at beginning\n2: Insertion at end\n3: Insertion at specific data node\n";
                    cout << "Enter your choice (1-3): ";
                    cin >> operationChoice;

                    cout << "Enter the value to be inserted: ";
                    cin >> value;

                    switch (operationChoice) {
                        case 1:
                            if (listChoice == 1)
                                sll.insertAtBeginning(value);
                            else if (listChoice == 2)
                                dll.insertAtBeginning(value);
                            else if (listChoice == 3)
                                cll.insertAtBeginning(value);
                            break;
                        case 2:
                            if (listChoice == 1)
                                sll.insertAtEnd(value);
                            else if (listChoice == 2)
                                dll.insertAtEnd(value);
                            else if (listChoice == 3)
                                cll.insertAtEnd(value);
                            break;
                        case 3:
                            cout << "Enter the position to insert at: ";
                            cin >> position;
                            if (listChoice == 1)
                                sll.insertAtPosition(value, position);
                            else if (listChoice == 2)
                                dll.insertAtPosition(value, position);
                            else if (listChoice == 3)
                                cll.insertAtPosition(value, position);
                            break;
                        default:
                            cout << "Invalid choice.\n";
                            break;
                    }
                    break;
                case 2:
                    cout << "Enter the value to be deleted: ";
                    cin >> value;
                    if (listChoice == 1)
                        sll.deleteNode(value);
                    else if (listChoice == 2)
                        dll.deleteNode(value);
                    else if (listChoice == 3)
                        cll.deleteNode(value);
                    break;
                case 3:
                    cout << "Displaying the linked list:\n";
                    if (listChoice == 1)
                        sll.display();
                    else if (listChoice == 2)
                        dll.display();
                    else if (listChoice == 3)
                        cll.display();
                    break;
                case 4:
                    cout << "Reversing the linked list.\n";
                    if (listChoice == 1)
                        sll.reverse();
                    else if (listChoice == 2)
                        dll.reverse();
                    else if (listChoice == 3)
                        cll.reverse();
                    break;
                case 5:
                    cout << "Enter the value to seek: ";
                    cin >> value;
                    if (listChoice == 1)
                        sll.seek(value);
                    else if (listChoice == 2)
                        dll.seek(value);
                    else if (listChoice == 3)
                        cll.seek(value);
                    break;
                case 6:
                    cout << "Exiting...\n";
                    return 0;
                default:
                    cout << "Invalid choice.\n";
                    break;
            }
        }
    }

    return 0;
}

